# Production Starting

This folder is used for overleaf production environment.

## System Requirement
To enjoy your tex writing, you need:
- At least 2 core, 2 GB mem
- At least 32GB storeage


