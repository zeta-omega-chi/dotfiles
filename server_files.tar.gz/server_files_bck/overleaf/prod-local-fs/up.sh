# /bin/bash

export CURRENT_DIR=$(pwd)

docker-compose up -d