return { -- a table of overrides/changes to the duskfox theme
  Normal = { bg = "#000000" },
}
